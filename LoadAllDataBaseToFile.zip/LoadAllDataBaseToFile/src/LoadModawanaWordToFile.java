import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


public class LoadModawanaWordToFile {
	static Connection con = DBModawanaWord.getConnection();
	public static ArrayList<String> records = new ArrayList<String>();

	public static String removeSamples(String string) {
		String samples = "+_()*&^%$#@!><؛×÷‘|:\'\\;/،ـ][؟,.’|~}«»{-=×€ß,~„ø¥¢°" + '"';
		String newString = "";
		for (int i = 0; i < string.length(); i++) {
			if (samples.indexOf(string.charAt(i)) == -1) {
				newString += string.charAt(i);
			}
		}
		return newString;
	}
	
	
	public static ArrayList<String> getRows(char c) throws SQLException {
		
		ArrayList<String>allTable = new ArrayList<String>();
		String tableName;
		if(c == 'آ' || c == 'ء' || c == 'أ' || c == 'إ')
			tableName = "primary_t_" + (-1 * (c - 'ا'));
		else
			tableName = "primary_t" + (c - 'ا');
		
		String sql = "SELECT * FROM " + tableName + "; ";
		System.out.println(sql);
		PreparedStatement stmt;
		stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();

		String s="";
		while (rs.next()) {
			ArrayList<String>arr = new ArrayList<>();
			s = rs.getString("id") + "*" + removeSamples(rs.getString("word")) + "*" + rs.getString("count");
			System.out.println();
			allTable.add(s);			
			
		}
		rs.close();
		stmt.close();
		return allTable;

	}
	
	public static String SecondryAndcount (char c , String p_id) throws SQLException {
		Set<String> setOfword1 = new HashSet<>();
        
		String tableName;
		if(c == 'آ' || c == 'ء' || c == 'أ' || c == 'إ')
			tableName = "secondary_t_" + (-1 * (c - 'ا'));
		else
			tableName = "secondary_t" + (c - 'ا');
		System.out.println(tableName);
		String sql = "SELECT word, count FROM " + tableName + " WHERE p_id = " +"'" + p_id +"'"+ " ; ";
		System.out.println(sql);
		PreparedStatement stmt;
		stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		String result = "";
		while (rs.next()) {
			ArrayList<String>arr = new ArrayList<>();
			String word = rs.getString("word");
			String count = rs.getString("count");
			word = removeSamples(word);
			result += word + "#" + count + "$";
			
			
		}
		rs.close();
		stmt.close();
		return result;

	}
	
	
	public static void writeFile() throws IOException {
		File fout = new File("modwanaWord.txt");
		FileOutputStream fos = new FileOutputStream(fout);
	 
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
	 
		for (int i = 0; i < records.size(); i++) {
			bw.write(records.get(i));
			bw.newLine();
		}
	 
		bw.close();
	}
	public static void main(String[] args) throws SQLException, IOException {
		   String chars = "ابتثجحخدذرزسشصضطظعغفقكلمنهويآءأإىؤئةڤپچژڛڈڠڪںهٹڑګڻۋ";
    	ArrayList<String> allrows = new ArrayList<String>();  
	    for (int cnt = 0 ; cnt<chars.length() ; cnt++){
	    	allrows = getRows(chars.charAt(cnt));
	        
	    	for(int row = 0; row < allrows.size(); row++)
	    	{
	    		String s = allrows.get(row);
	    		String arr[] = s.split("\\*");
	    		String p_id = arr[0];
	    		String word = arr[1];
	    		String count = arr[2];
	    	
	    		String record = word + "#" + count + "$" + SecondryAndcount(chars.charAt(cnt), p_id);
	    		records.add(record);

	    	} 

	    }
	    writeFile();
	    

	}	}


